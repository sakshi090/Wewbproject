<?php
session_start();
include "../dbcon.php";

// Check if the customer is logged in
if (!isset($_SESSION['user_id'])) {
    header('location:../index.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Handle "Mark as Done" action (for assigned tasks)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['task_id'])) {
    $task_id = mysqli_real_escape_string($con, $_POST['task_id']); // Prevent SQL Injection

    // Delete the assigned task from the database
    $delete_task_qry = "DELETE FROM tasks WHERE id = $task_id AND customer_id = $user_id";
    if (mysqli_query($con, $delete_task_qry)) {
        echo "<script>alert('Task marked as done and deleted successfully!'); window.location.href='dashboard.php';</script>";
    } else {
        echo "<script>alert('Error deleting task: " . mysqli_error($con) . "');</script>";
    }
}

// Fetch user's personal tasks
$user_tasks_qry = "SELECT id, task_desc, task_status FROM todo WHERE user_id = $user_id";
$user_tasks_result = mysqli_query($con, $user_tasks_qry);
if (!$user_tasks_result) {
    die("Error fetching user's tasks: " . mysqli_error($con));
}

// Fetch staff-assigned tasks
$assigned_tasks_qry = "SELECT id, task_description, created_at, status FROM tasks WHERE customer_id = $user_id";
$assigned_tasks_result = mysqli_query($con, $assigned_tasks_qry);
if (!$assigned_tasks_result) {
    die("Error fetching assigned tasks: " . mysqli_error($con));
}

// Fetch announcements
$announcements_qry = "SELECT message, date FROM announcements";
$announcements_result = mysqli_query($con, $announcements_qry);
if (!$announcements_result) {
    die("Error fetching announcements: " . mysqli_error($con));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Tasks and Announcements</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/bootstrap.min.css" />
    <link rel="stylesheet" href="../css/bootstrap-responsive.min.css" />
    <link rel="stylesheet" href="../css/fullcalendar.css" />
    <link rel="stylesheet" href="../css/matrix-style.css" />
    <link rel="stylesheet" href="../css/matrix-media.css" />
    <link href="../font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" href="../css/jquery.gritter.css" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>

<!--Header-part-->
<div id="header">
  <h1><a href="index.php">Perfect Gym System</a></h1>
</div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<?php include '../includes/topheader.php'?>
<!--close-top-Header-menu-->

<!--sidebar-menu-->
<?php $page="dashboard"; include '../includes/sidebar.php'?>
<!--sidebar-menu-->
<div class="container mt-5">
    <h1 class="text-center">Dashboard</h1>

    <!-- Announcements -->
    <h2 class="text-center mt-4">Announcements</h2>
    <div class="card">
        <div class="card-body">
            <?php if (mysqli_num_rows($announcements_result) > 0): ?>
                <ul class="list-group">
                    <?php while ($announcement = mysqli_fetch_assoc($announcements_result)): ?>
                        <li class="list-group-item">
                            <strong>Date:</strong> <?= htmlspecialchars($announcement['date']) ?><br>
                            <?= htmlspecialchars($announcement['message']) ?>
                        </li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p class="text-center">No announcements available.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- User's Personal Tasks -->
    <h2 class="text-center mt-5">My To-Do List</h2>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>Task Description</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php if (mysqli_num_rows($user_tasks_result) > 0): ?>
            <?php while ($task = mysqli_fetch_assoc($user_tasks_result)): ?>
                <tr>
                    <td><?= htmlspecialchars($task['task_desc']) ?></td>
                    <td><?= htmlspecialchars($task['task_status']) ?></td>
                    <td>
                        <a href="actions/remove-todo.php?id=<?= $task['id'] ?>" class="btn btn-danger btn-sm">Mark as Done</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="3" class="text-center">No personal tasks found.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>

    <!-- Assigned Tasks -->
    <h2 class="text-center mt-5">Assigned Tasks</h2>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>Task Description</th>
            <th>Assigned Date</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php if (mysqli_num_rows($assigned_tasks_result) > 0): ?>
            <?php while ($task = mysqli_fetch_assoc($assigned_tasks_result)): ?>
                <tr>
                    <td><?= htmlspecialchars($task['task_description']) ?></td>
                    <td><?= date('d-m-Y H:i:s', strtotime($task['created_at'])) ?></td>
                    <td><?= htmlspecialchars($task['status'] ?? 'Pending') ?></td>
                    <td>
                        <form method="post" style="display: inline-block;">
                            <input type="hidden" name="task_id" value="<?= $task['id'] ?>">
                            <button type="submit" class="btn btn-danger btn-sm">Mark as Done</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="4" class="text-center">No assigned tasks found.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<script src="../js/jquery.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
</body>
</html>
