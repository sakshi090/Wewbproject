<?php
// Include session.php to start the session at the very beginning
include 'session.php';  // This file already calls session_start()
include "../dbcon.php";

// Check if the customer is logged in
if (!isset($_SESSION['user_id'])) {
    header('location:../index.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Handle "Mark as Done" action (for assigned tasks)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['task_id'])) {
    $task_id = mysqli_real_escape_string($con, $_POST['task_id']); // Prevent SQL Injection

    // Delete the assigned task from the database
    $delete_task_qry = "DELETE FROM tasks WHERE id = $task_id AND customer_id = $user_id";
    if (mysqli_query($con, $delete_task_qry)) {
         "<script> window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Error deleting task: " . mysqli_error($con) . "');</script>";
    }
}

// Fetch user's personal tasks
$user_tasks_qry = "SELECT id, task_desc, task_status FROM todo WHERE user_id = $user_id";
$user_tasks_result = mysqli_query($con, $user_tasks_qry);
if (!$user_tasks_result) {
    die("Error fetching user's tasks: " . mysqli_error($con));
}

// Fetch staff-assigned tasks
$assigned_tasks_qry = "SELECT id, task_description, created_at, status FROM tasks WHERE customer_id = $user_id";
$assigned_tasks_result = mysqli_query($con, $assigned_tasks_qry);
if (!$assigned_tasks_result) {
    die("Error fetching assigned tasks: " . mysqli_error($con));
}

// Fetch announcements
$announcements_qry = "SELECT message, date FROM announcements";
$announcements_result = mysqli_query($con, $announcements_qry);
if (!$announcements_result) {
    die("Error fetching announcements: " . mysqli_error($con));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Gym System</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/bootstrap.min.css" />
    <link rel="stylesheet" href="../css/bootstrap-responsive.min.css" />
    <link rel="stylesheet" href="../css/fullcalendar.css" />
    <link rel="stylesheet" href="../css/matrix-style.css" />
    <link rel="stylesheet" href="../css/matrix-media.css" />
    <link href="../font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" href="../css/jquery.gritter.css" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>

<!--Header-part-->
<div id="header">
    <h1><a href="index.php">Perfect Gym System</a></h1>
</div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<?php include '../includes/topheader.php'; ?>
<!--close-top-Header-menu-->

<!--sidebar-menu-->
<?php $page = "dashboard"; include '../includes/sidebar.php'; ?>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content">
    <!--breadcrumbs-->
    <div id="content-header">
        <div id="breadcrumb"> <a href="index.php" title="You're right here" class="tip-bottom"><i class="icon-home"></i> Home</a></div>
    </div>
    <!--End-breadcrumbs-->

    <!--Action boxes-->
    <div class="container-fluid">
        <!--End-Action boxes-->    

        <div class="row-fluid">
            <div class="span6">
                <div class="widget-box">
                    <div class="widget-title"> <span class="icon"><i class="icon-time"></i></span>
                        <h5>My To-Do List</h5>
                    </div>
                    <div class="widget-content nopadding">

                        <?php
                        $qry = "SELECT * FROM todo WHERE user_id='" . $_SESSION['user_id'] . "'";
                        $result = mysqli_query($con, $qry);

                        echo "<table class='table table-striped table-bordered'>
                                <thead>
                                    <tr>
                                        <th>Description</th>
                                        <th>Status</th>
                                        <th>Opts</th>
                                    </tr>
                                </thead>";

                        while ($row = mysqli_fetch_array($result)) {
                            echo "<tbody>
                                    <tr>
                                        <td class='taskDesc'><a href='to-do.php'><i class='icon-plus-sign'></i></a>" . $row['task_desc'] . "</td>
                                        <td class='taskStatus'><span class='in-progress'>" . $row['task_status'] . "</span></td>
                                        <td class='taskOptions'>
                                            <a href='update-todo.php?id=" . $row['id'] . "' class='tip-top' data-original-title='Update'><i class='icon-edit'></i></a>  
                                            <a href='actions/remove-todo.php?id=" . $row['id'] . "' class='tip-top' data-original-title='Done'><i class='icon-ok'></i></a>
                                        </td>
                                    </tr>
                                  </tbody>";
                        }
                        ?>

                    </table>
                    </div>
                </div>

                <div class="widget-box">
                    <div class="widget-title"> <span class="icon"><i class="icon-time"></i></span>
                        <h5>Assigned Task</h5>
                    </div>
                    <div class="widget-content nopadding">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Task Description</th>
                                    <th>Assigned Date</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (mysqli_num_rows($assigned_tasks_result) > 0): ?>
                                    <?php while ($task = mysqli_fetch_assoc($assigned_tasks_result)): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($task['task_description']) ?></td>
                                            <td><?= date('d-m-Y H:i:s', strtotime($task['created_at'])) ?></td>
                                            <td><?= htmlspecialchars($task['status'] ?? 'Pending') ?></td>
                                            <td>
                                                <form method="post" style="display: inline-block;">
                                                    <input type="hidden" name="task_id" value="<?= $task['id'] ?>">
                                                    <button type="submit" class="btn btn-danger btn-sm">Mark as Done</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-center">No assigned tasks found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- End of ToDo List Bar -->

            <div class="span6">
                <div class="widget-box">
                    <div class="widget-title bg_ly" data-toggle="collapse" href="#collapseG2">
                        <span class="icon"><i class="icon-chevron-down"></i></span>
                        <h5>Gym Announcement</h5>
                    </div>
                    <div class="widget-content nopadding collapse in" id="collapseG2">
                        <ul class="recent-posts">
                            <li>
                                <?php
                                $qry = "select * from announcements";
                                $result = mysqli_query($con, $qry);

                                while ($row = mysqli_fetch_array($result)) {
                                    echo "<div class='user-thumb'> <img width='70' height='40' alt='User' src='../img/demo/av1.jpg'> </div>";
                                    echo "<div class='article-post'>"; 
                                    echo "<span class='user-info'> By: System Administrator / Date: " . $row['date'] . " </span>";
                                    echo "<p><a href='#'>" . $row['message'] . "</a> </p>";
                                }

                                echo "</div>";
                                echo "</li>";
                                ?>
                                <a href="announcement.php"><button class="btn btn-warning btn-mini">View All</button></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- end of announcement -->

        </div><!-- End of row-fluid -->
    </div><!-- End of container-fluid -->
</div><!-- End of content-ID -->

<!--Footer-part-->
<!-- <div class="row-fluid">
    <div id="footer" class="span12"> <?php echo date("Y");?> &copy; Developed By Naseeb Bajracharya</a> </div>
</div> -->

<style>
#footer {
    color: white;
}

.card {
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
    max-width: 460px;
    margin: auto;
    text-align: center;
}