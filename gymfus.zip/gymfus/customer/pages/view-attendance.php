<?php
session_start();
include '../dbcon.php';

// Ensure only logged-in customers can access
if (!isset($_SESSION['user_id'])) {
    header('location:../index.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch attendance for the logged-in customer
$qry = "SELECT * FROM attendance WHERE user_id = '$user_id' ORDER BY curr_date DESC, curr_time DESC";
$result = mysqli_query($con, $qry);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Customer - Attendance History</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/bootstrap.min.css" />
    <link rel="stylesheet" href="../css/matrix-style.css" />
    <link rel="stylesheet" href="../css/matrix-media.css" />
    <link href="../font-awesome/css/all.css" rel="stylesheet" />
</head>
<body>
<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h3 class="text-center">Attendance History</h3>
        </div>
        <div class="card-body">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Check-In Time</th>
                        <th>Check-Out Time</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>" . $row['curr_date'] . "</td>";
                            echo "<td>" . $row['curr_time'] . "</td>";
                            echo "<td>" . ($row['checkout_time'] ? $row['checkout_time'] : 'N/A') . "</td>";
                            echo "<td>" . ($row['present'] == 1 ? 'Present' : 'Absent') . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4' class='text-center'>No attendance records found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
            <div class="text-center">
                <a href="../pages/index.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
            </div>
        </div>
        <div class="card-footer text-muted text-center">
            &copy; <?php echo date("Y"); ?> Gym Management System
        </div>
    </div>
</div>

<script src="../js/jquery.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
</body>
</html>
