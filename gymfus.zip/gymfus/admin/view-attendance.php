<?php
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['user_id'])) {
    header('location:../index.php');
}

include "../dbcon.php";

// Generate CSV if the button is clicked
if (isset($_POST['download_csv'])) {
    date_default_timezone_set('Asia/Kolkata');
    $current_date = date('Y-m-d');

    header('Content-Type: text/csv');
    header('Content-Disposition: attachment;filename=staff_attendance_' . $current_date . '.csv');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['#', 'Fullname', 'Designation', 'Check-In Time', 'Check-Out Time']);

    $qry = "SELECT s.user_id, s.fullname, s.designation, 
            a.checkin_time, a.checkout_time 
            FROM staffs s 
            LEFT JOIN staff_attendance a 
            ON s.user_id = a.user_id AND a.curr_date = '$current_date'";
    $result = mysqli_query($con, $qry);
    $cnt = 1;

    while ($row = mysqli_fetch_assoc($result)) {
        fputcsv($output, [
            $cnt++,
            $row['fullname'],
            $row['designation'],
            $row['checkin_time'] ? $row['checkin_time'] : 'N/A',
            $row['checkout_time'] ? $row['checkout_time'] : 'N/A'
        ]);
    }

    fclose($output);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Panel - Staff Attendance</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/bootstrap.min.css" />
    <link rel="stylesheet" href="../css/matrix-style.css" />
    <link rel="stylesheet" href="../css/matrix-media.css" />
    <link rel="stylesheet" href="../font-awesome/css/all.css" />
</head>
<body>
<!--Header-part-->
<div id="header">
  <h1><a href="dashboard.html">Perfect Gym Admin</a></h1>
</div>
<!--close-Header-part--> 

<!--sidebar-menu-->
<?php $page="view-attendance"; include 'includes/sidebar.php'?>
<!--sidebar-menu-->

<div id="content">
    <div id="content-header">
        <h1 class="text-center">Staff Attendance</h1>
    </div>
    <div class="container-fluid">
        <!-- Download Button -->
        <form method="post">
            <button type="submit" name="download_csv" class="btn btn-success mb-3">
                <i class="fa fa-download"></i> Download Attendance
            </button>
        </form>

        <!-- Attendance Table -->
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Fullname</th>
                    <th>Designation</th>
                    <th>Check-In Time</th>
                    <th>Check-Out Time</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                date_default_timezone_set('Asia/Kolkata');
                $current_date = date('Y-m-d');
                $qry = "SELECT s.user_id, s.fullname, s.designation, 
                        a.checkin_time, a.checkout_time 
                        FROM staffs s 
                        LEFT JOIN staff_attendance a 
                        ON s.user_id = a.user_id AND a.curr_date = '$current_date'";
                $result = mysqli_query($con, $qry);
                $cnt = 1;

                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $cnt . "</td>";
                    echo "<td>" . $row['fullname'] . "</td>";
                    echo "<td>" . $row['designation'] . "</td>";
                    echo "<td>" . ($row['checkin_time'] ? $row['checkin_time'] : 'N/A') . "</td>";
                    echo "<td>" . ($row['checkout_time'] ? $row['checkout_time'] : 'N/A') . "</td>";

                    // Check-in button is always shown if the user has checked out
                    echo "<td>
                            <a href='actions/markstaff-attendance.php?id=" . $row['user_id'] . "'>
                                <button class='btn btn-info'>Check In</button>
                            </a>";

                    // If not yet checked out, show the Check-Out button
                    if (!$row['checkout_time']) {
                        echo " <a href='actions/staffcheckout-attendance.php?id=" . $row['user_id'] . "'>
                                    <button class='btn btn-danger'>Check Out</button>
                                </a>";
                    }

                    echo "</td>";
                    echo "</tr>";
                    $cnt++;
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<script src="../js/jquery.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
</body>
</html>
