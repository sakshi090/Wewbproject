<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('location:../index.php');
    exit();
}
include "../dbcon.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Gym System Admin</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/bootstrap.min.css" />
    <link rel="stylesheet" href="../css/matrix-style.css" />
    <link rel="stylesheet" href="../css/matrix-media.css" />
    <link rel="stylesheet" href="../font-awesome/css/all.css" />
    <style>
        .download-btn {
            margin: 10px 0;
        }
    </style>
</head>
<body>
<!--Header-part-->
<div id="header">
  <h1><a href="dashboard.php">Perfect Gym Admin</a></h1>
</div>
<!--close-Header-part--> 


<!--top-Header-menu-->
<?php include 'includes/topheader.php'?>
<!--close-top-Header-menu-->
<!--start-top-serch-->
<!-- <div id="search">
  <input type="hidden" placeholder="Search here..."/>
  <button type="submit" class="tip-bottom" title="Search"><i class="icon-search icon-white"></i></button>
</div> -->
<!--close-top-serch-->
<!--sidebar-menu-->
<?php $page='attendance'; include 'includes/sidebar.php'?>
<!--sidebar-menu-->

<div id="content">
    <div id="content-header">
    <div id="breadcrumb"> <a href="index.php" title="Go to Home" class="tip-bottom"><i class="fa fa-home"></i> Home</a> <a href="#" class="tip-bottom">Member Attendance</a> <a href="#" class="current">Add Members</a> </div>
        <h1 class="text-center">Attendance List <i class="fas fa-calendar"></i></h1>
    </div>
    <div class="container-fluid">
        <div class="row-fluid">
            <div class="span12">
                <div class="text-right download-btn">
                    <a href="actions/download-attendance.php" class="btn btn-success">
                        Download Attendance <i class="fas fa-download"></i>
                    </a>
                </div>
                <div class='widget-box'>
                    <div class='widget-title'>
                        <h5>Attendance Table</h5>
                    </div>
                    <div class='widget-content nopadding'>
                        <table class='table table-bordered table-hover'>
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Fullname</th>
                                    <th>Contact</th>
                                    <th>Service</th>
                                    <th>Check-In Time</th>
                                    <th>Check-Out Time</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                date_default_timezone_set('Asia/Kolkata'); // Set timezone to IST
                                $current_date = date('Y-m-d');
                                $qry = "SELECT members.user_id, members.fullname, members.contact, members.services, 
                                        attendance.curr_time AS checkin_time, attendance.checkout_time 
                                        FROM members 
                                        LEFT JOIN attendance ON members.user_id = attendance.user_id 
                                        AND attendance.curr_date = '$current_date'
                                        WHERE members.status = 'Active'";
                                $result = mysqli_query($conn, $qry);
                                $cnt = 1;

                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr>";
                                    echo "<td>" . $cnt . "</td>";
                                    echo "<td>" . $row['fullname'] . "</td>";
                                    echo "<td>" . $row['contact'] . "</td>";
                                    echo "<td>" . $row['services'] . "</td>";
                                    echo "<td>" . ($row['checkin_time'] ? $row['checkin_time'] : 'N/A') . "</td>";
                                    echo "<td>" . ($row['checkout_time'] ? $row['checkout_time'] : 'N/A') . "</td>";

                                    // Logic to display buttons
                                    if (!$row['checkin_time']) {
                                        echo "<td>
                                            <a href='actions/mark-attendance.php?id=" . $row['user_id'] . "'>
                                                <button class='btn btn-info'>Check In <i class='fas fa-map-marker-alt'></i></button>
                                            </a>
                                        </td>";
                                    } elseif (!$row['checkout_time']) {
                                        echo "<td>
                                            <a href='actions/checkout-attendance.php?id=" . $row['user_id'] . "'>
                                                <button class='btn btn-danger'>Check Out <i class='fas fa-clock'></i></button>
                                            </a>
                                        </td>";
                                    } else {
                                        echo "<td>
                                            <a href='actions/mark-attendance.php?id=" . $row['user_id'] . "'>
                                                <button class='btn btn-info'>Check In <i class='fas fa-map-marker-alt'></i></button>
                                            </a>
                                        </td>";
                                    }

                                    echo "</tr>";
                                    $cnt++;
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="../js/jquery.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
</body>
</html>
