<?php
session_start();
include('dbcon.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('location:index.php');
    exit();
}

if (isset($_POST['change_password'])) {
    $user_id = $_SESSION['user_id'];
    $old_password = mysqli_real_escape_string($con, $_POST['old_password']);
    $new_password = mysqli_real_escape_string($con, $_POST['new_password']);
    $confirm_password = mysqli_real_escape_string($con, $_POST['confirm_password']);

    // Hash the old password for verification
    $old_password_hashed = md5($old_password);

    // Fetch the current password from the database
    $query = mysqli_query($con, "SELECT password FROM admin WHERE user_id = '$user_id'");
    $row = mysqli_fetch_array($query);

    if ($row['password'] === $old_password_hashed) {
        if ($new_password === $confirm_password) {
            $new_password_hashed = md5($new_password);
            mysqli_query($con, "UPDATE admin SET password = '$new_password_hashed' WHERE user_id = '$user_id'");
            echo "<div class='alert alert-success'>Password successfully changed.</div>";
        } else {
            echo "<div class='alert alert-danger'>New passwords do not match.</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>Incorrect old password.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Change Password</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/matrix-style.css" />
</head>
<body>
    <div id="loginbox">
        <form method="POST" class="form-vertical">
            <div class="control-group normal_text"> 
                <h3>Change Password</h3>
            </div>
            <div class="control-group">
                <div class="controls">
                    <div class="main_input_box">
                        <span class="add-on bg_ly"><i class="fas fa-lock"></i></span>
                        <input type="password" name="old_password" placeholder="Old Password" required />
                    </div>
                </div>
            </div>
            <div class="control-group">
                <div class="controls">
                    <div class="main_input_box">
                        <span class="add-on bg_ly"><i class="fas fa-lock"></i></span>
                        <input type="password" name="new_password" placeholder="New Password" required />
                    </div>
                </div>
            </div>
            <div class="control-group">
                <div class="controls">
                    <div class="main_input_box">
                        <span class="add-on bg_ly"><i class="fas fa-lock"></i></span>
                        <input type="password" name="confirm_password" placeholder="Confirm New Password" required />
                    </div>
                </div>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn btn-block btn-large btn-info" name="change_password">Change Password</button>
            </div>
        </form>
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
