<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('location:../index.php');
    exit();
}
include "../dbcon.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin - Staff Attendance</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/bootstrap.min.css" />
    <link rel="stylesheet" href="../css/matrix-style.css" />
    <link rel="stylesheet" href="../css/matrix-media.css" />
    <link rel="stylesheet" href="../font-awesome/css/all.css" />
</head>
<body>
<div id="header">
    <h1>Admin Panel - Staff Attendance</h1>
</div>

<!-- Sidebar -->
<?php $page = "attendance"; include 'includes/sidebar.php'; ?>

<div id="content">
    <div id="content-header">
        <h1 class="text-center">Staff Attendance <i class="fas fa-calendar-check"></i></h1>
    </div>
    <div class="container-fluid">
        <div class="row-fluid">
            <div class="span12">
                <div class="widget-box">
                    <div class="widget-title">
                        <h5>Attendance Table</h5>
                        <div class="pull-right">
                            <a href="actions/download_attendance.php" class="btn btn-success">
                                <i class="fas fa-download"></i> Download Attendance
                            </a>
                        </div>
                    </div>
                    <div class="widget-content nopadding">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Full Name</th>
                                    <th>Check-In</th>
                                    <th>Check-Out</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Set timezone and current date
                                date_default_timezone_set('Asia/Kolkata');
                                $current_date = date('Y-m-d');

                                // Query to get staff attendance
                                $qry = "SELECT staffs.user_id, staffs.fullname, 
                                        staff_attendance.attendance_id, staff_attendance.checkin_time, 
                                        staff_attendance.checkout_time 
                                        FROM staffs 
                                        LEFT JOIN staff_attendance 
                                        ON staffs.user_id = staff_attendance.user_id 
                                        AND staff_attendance.curr_date = '$current_date' 
                                        ORDER BY staffs.user_id, staff_attendance.attendance_id ASC";

                                $result = mysqli_query($con, $qry);
                                $cnt = 1;

                                // Loop through the query results
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr>";
                                    echo "<td>" . $cnt . "</td>";
                                    echo "<td>" . $row['fullname'] . "</td>";
                                    echo "<td>" . ($row['checkin_time'] ? $row['checkin_time'] : 'N/A') . "</td>";
                                    echo "<td>" . ($row['checkout_time'] ? $row['checkout_time'] : 'N/A') . "</td>";

                                    // Determine which button to show
                                    if (!$row['checkin_time'] || ($row['checkin_time'] && $row['checkout_time'])) {
                                        // Show "Check In" button if there's no check-in or the previous check-in/out is completed
                                        echo "<td>
                                                <a href='actions/mark_staff_attendance.php?id=" . $row['user_id'] . "'>
                                                    <button class='btn btn-info'>Check In</button>
                                                </a>
                                            </td>";
                                    } elseif ($row['checkin_time'] && !$row['checkout_time']) {
                                        // Show "Check Out" button if there's a check-in but no checkout
                                        echo "<td>
                                                <a href='actions/mark_staff_checkout.php?id=" . $row['attendance_id'] . "'>
                                                    <button class='btn btn-danger'>Check Out</button>
                                                </a>
                                            </td>";
                                    } else {
                                        // Attendance fully marked for the day
                                        echo "<td>
                                                <span class='text-success'>Attendance Marked</span>
                                            </td>";
                                    }
                                    echo "</tr>";
                                    $cnt++;
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="../js/jquery.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
</body>
</html>
