<?php
session_start();
include '../../dbcon.php';

if (!isset($_SESSION['user_id'])) {
    header('location:../../index.php');
    exit();
}

if (isset($_GET['id'])) {
    $user_id = $_GET['id'];
    date_default_timezone_set('Asia/Kolkata');
    $current_time = date('H:i:s');
    $current_date = date('Y-m-d');

    $qry = "INSERT INTO staff_attendance (user_id, curr_date, checkin_time) 
            VALUES ('$user_id', '$current_date', '$current_time')";
    if (mysqli_query($con, $qry)) {
        header('location:../ATTENDANCE-BACKUP.php?success=Check-in successful');
    } else {
        echo "Error: " . mysqli_error($con);
    }
} else {
    header('location:../ATTENDANCE-BACKUP.php?error=Invalid user');
    exit();
}
?>
