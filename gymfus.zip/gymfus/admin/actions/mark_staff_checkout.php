<?php
session_start();
include '../../dbcon.php';

if (!isset($_SESSION['user_id'])) {
    header('location:../../index.php');
    exit();
}

if (isset($_GET['id'])) {
    $attendance_id = $_GET['id'];
    date_default_timezone_set('Asia/Kolkata');
    $current_time = date('H:i:s');

    $qry = "UPDATE staff_attendance 
            SET checkout_time = '$current_time' 
            WHERE attendance_id = '$attendance_id'";
    if (mysqli_query($con, $qry)) {
        header('location:../ATTENDANCE-BACKUP.php?success=Check-out successful');
    } else {
        echo "Error: " . mysqli_error($con);
    }
} else {
    header('location:../ATTENDANCE-BACKUP.php?error=Invalid request');
    exit();
}
?>
