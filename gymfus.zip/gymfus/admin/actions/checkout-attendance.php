<?php
session_start();
include '../../dbcon.php';

if (!isset($_SESSION['user_id'])) {
    header('location:../../index.php');
    exit();
}

if (isset($_GET['id'])) {
    $user_id = $_GET['id'];
    date_default_timezone_set('Asia/Kolkata');
    $current_time = date('H:i:s');
    $current_date = date('Y-m-d');

    $qry = "UPDATE attendance SET checkout_time = '$current_time' 
            WHERE user_id = '$user_id' AND curr_date = '$current_date'";
    if (mysqli_query($con, $qry)) {
        header('location:../attendance.php?success=Check-out successful');
    } else {
        echo "Error: " . mysqli_error($con);
    }
} else {
    header('location:../attendance.php?error=Invalid user');
    exit();
}
?>
