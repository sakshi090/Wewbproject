<?php
session_start();
include '../../dbcon.php';

if (!isset($_SESSION['user_id'])) {
    header('location:../../index.php');
    exit();
}

if (isset($_GET['id'])) {
    $user_id = $_GET['id'];
    date_default_timezone_set('Asia/Kolkata');
    $current_time = date('H:i:s');
    $current_date = date('Y-m-d');

    // Insert attendance record with 'present' column
    $qry = "INSERT INTO attendance (user_id, curr_date, curr_time, present) 
            VALUES ('$user_id', '$current_date', '$current_time', 1)";
    if (mysqli_query($con, $qry)) {
        header('location:../attendance.php?success=Check-in successful');
    } else {
        echo "Error: " . mysqli_error($con);
    }
} else {
    header('location:../attendance.php?error=Invalid user');
    exit();
}
?>
