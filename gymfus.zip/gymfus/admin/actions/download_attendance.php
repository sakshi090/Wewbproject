<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('location:../index.php');
    exit();
}
include "../dbcon.php";

// Set headers for the CSV file download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=attendance.csv');

// Output buffer
$output = fopen('php://output', 'w');

// Add column headers
fputcsv($output, ['#', 'Full Name', 'Check-In', 'Check-Out', 'Date']);

// Query attendance data
date_default_timezone_set('Asia/Kolkata');
$current_date = date('Y-m-d');

$qry = "SELECT staffs.user_id, staffs.fullname, 
        staff_attendance.checkin_time, staff_attendance.checkout_time, staff_attendance.curr_date 
        FROM staffs 
        LEFT JOIN staff_attendance 
        ON staffs.user_id = staff_attendance.user_id 
        WHERE staff_attendance.curr_date = '$current_date' 
        ORDER BY staffs.user_id";

$result = mysqli_query($con, $qry);
$cnt = 1;

// Loop through the results and write to the CSV
while ($row = mysqli_fetch_assoc($result)) {
    fputcsv($output, [
        $cnt,
        $row['fullname'],
        $row['checkin_time'] ? $row['checkin_time'] : 'N/A',
        $row['checkout_time'] ? $row['checkout_time'] : 'N/A',
        $row['curr_date']
    ]);
    $cnt++;
}

// Close the output buffer
fclose($output);
?>
