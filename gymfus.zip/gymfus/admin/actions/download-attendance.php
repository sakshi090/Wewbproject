<?php
session_start();
include '../../dbcon.php';

if (!isset($_SESSION['user_id'])) {
    header('location:../../index.php');
    exit();
}

// Set the headers for downloading as a CSV file
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=attendance.csv');

// Create a file pointer
$output = fopen('php://output', 'w');

// Add the column headers
fputcsv($output, ['#', 'Fullname', 'Contact', 'Service', 'Check-In Time', 'Check-Out Time']);

$qry = "SELECT members.fullname, members.contact, members.services, 
        attendance.curr_time AS checkin_time, attendance.checkout_time 
        FROM members 
        LEFT JOIN attendance ON members.user_id = attendance.user_id 
        ORDER BY attendance.curr_date DESC, attendance.curr_time DESC";
$result = mysqli_query($con, $qry);

$cnt = 1;

// Add rows to the CSV
while ($row = mysqli_fetch_assoc($result)) {
    fputcsv($output, [
        $cnt,
        $row['fullname'],
        $row['contact'],
        $row['services'],
        $row['checkin_time'] ?: 'N/A',
        $row['checkout_time'] ?: 'N/A'
    ]);
    $cnt++;
}

// Close the file pointer
fclose($output);
exit();
?>
