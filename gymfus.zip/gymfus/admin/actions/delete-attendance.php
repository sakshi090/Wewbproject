<?php
session_start();
include '../../dbcon.php';

if (!isset($_SESSION['user_id'])) {
    header('location:../../index.php');
    exit();
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete attendance record
    $qry = "DELETE FROM attendance WHERE id = '$id'";
    if (mysqli_query($con, $qry)) {
        header('location:../attendance.php?success=Attendance removed successfully');
    } else {
        header('location:../attendance.php?error=Failed to remove attendance');
    }
} else {
    header('location:../attendance.php?error=Invalid attendance ID');
}
?>
