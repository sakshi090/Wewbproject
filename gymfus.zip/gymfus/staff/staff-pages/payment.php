<?php
session_start();
include "../dbcon.php";

// Check if the staff is logged in
if (!isset($_SESSION['user_id'])) {
    header('location:../index.php');
    exit;
}

// Handle task submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_id = $_POST['customer_id']; // Fixed the input name to match form
    $staff_id = $_SESSION['user_id'];
    $task_description = mysqli_real_escape_string($con, $_POST['task_description']);

    $qry = "INSERT INTO tasks (customer_id, staff_id, task_description) VALUES ('$customer_id', '$staff_id', '$task_description')";
    if (mysqli_query($con, $qry)) {
        echo "<script>alert('Task assigned successfully!');</script>";
    } else {
        echo "<script>alert('Error: " . mysqli_error($con) . "');</script>";
    }
}

// Fetch all customers
$customers = mysqli_query($con, "SELECT user_id, fullname FROM members WHERE status = 'Active'");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Assign Tasks to Customers</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/matrix-style.css" />
    <link rel="stylesheet" href="../css/matrix-media.css" />
    <link href="../font-awesome/css/font-awesome.css" rel="stylesheet" />
</head>
<body>

<div id="header">
  <h1><a href="dashboard.html">Perfect Gym</a></h1>
</div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<?php include '../includes/header.php'?>
<!--close-top-Header-menu-->

<?php $page="payment"; include '../includes/sidebar.php'?>

<!-- Content -->
<div id="content">
    <div id="content-header">
        <div id="breadcrumb">
            <a href="index.php" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a>
            <a href="payment.php" class="current">Assign Tasks</a>
        </div>
        <h1 class="text-center">Assign Tasks to Members <i class="icon icon-tasks"></i></h1>
    </div>
    <div class="container-fluid">
        <hr>
        <div class="row-fluid">
            <div class="span12">
                <div class="widget-box">
                    <div class="widget-title">
                        <span class="icon"><i class="icon-th"></i></span>
                        <h5>Assign Task</h5>
                    </div>
                    <div class="widget-content nopadding">
                        <div class="container" style="padding: 20px;">
                            <form method="post">
                                <div class="form-group">
                                    <label for="customer_id">Select Customer</label>
                                    <select id="customer_id" name="customer_id" class="form-control" required>
                                        <option value="">-- Select Customer --</option>
                                        <?php while ($customer = mysqli_fetch_assoc($customers)) { ?>
                                            <option value="<?= $customer['user_id'] ?>"><?= $customer['fullname'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="task_description">Task Description</label>
                                    <textarea id="task_description" name="task_description" class="form-control" rows="3" required></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary">Assign Task</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<!-- <div class="row-fluid">
    <div id="footer" class="span12"> <?= date("Y"); ?> &copy; Developed By Your Name </div>
</div> -->

<script src="../js/jquery.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/matrix.js"></script>

</body>
</html>
